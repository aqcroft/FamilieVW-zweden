RONDREIS ZWEDEN 2026 - INTERACTIEVE REISPLANNER v1

INHOUD
- index.html: interactieve kaart en dag-tot-dag reisplanner
- Rondreis_Zweden_meren_Stockholm_Goteborg_2026.pdf: originele agenda
- README.txt: deze uitleg

OPENEN
1. Pak het ZIP-bestand uit.
2. Open index.html in Chrome, Edge, Safari of Firefox.
3. Een internetverbinding is nodig voor de achtergrondkaart van OpenStreetMap.
4. Reserveringsstatussen en eigen notities worden lokaal in de browser opgeslagen.

DELEN
De map kan als geheel worden geüpload naar GitHub Pages of een andere eenvoudige webhost.
Daarna kan index.html via een normale link worden gedeeld.

BELANGRIJK
- Kaartposities en routeverbindingen zijn indicatief.
- Dit is geen gecertificeerde campernavigatie.
- Controleer openingstijden, bootdiensten, campingbeschikbaarheid, tol- en voertuigcategorieën,
  weersomstandigheden en toegangsregels vlak voor vertrek.
